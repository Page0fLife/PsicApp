package com.example.apppsicologia.Repository

import com.example.apppsicologia.Model.Med

class MedRepository {
    private var repository: com.example.apppsicologia.Repository.MedRepository? = null

    fun getInstance(): com.example.apppsicologia.Repository.MedRepository? {
        if (repository == null) {
            repository = com.example.apppsicologia.Repository.MedRepository()
        }
        return repository
    }

    private val medList: ArrayList<Med> = ArrayList<Med>()

    fun save(med: Med) {
        medList.add(med)
    }

    fun delete(med: Med) {
        medList.remove(med)
    }

    fun getAll(): ArrayList<Med>? {
        return medList
    }

    fun getByIndex(index: Int): Med? {
        return medList[index]
    }

    fun update(index: Int, gift: Med) {
        medList[index] = gift
    }
}