package com.example.apppsicologia.Model

class Usuario (val id: Number?,
               val email: String,
               val senha: String)