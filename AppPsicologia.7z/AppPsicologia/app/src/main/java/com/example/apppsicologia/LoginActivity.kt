package com.example.apppsicologia;

import android.app.ProgressDialog
import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.text.TextUtils
import android.util.Patterns
import android.widget.Toast
import androidx.appcompat.app.ActionBar
import com.example.apppsicologia.databinding.ActivityLoginBinding
import com.google.firebase.auth.FirebaseAuth

class LoginActivity : AppCompatActivity() {
    private lateinit var binding: ActivityLoginBinding

    private lateinit var actionBar: ActionBar

    private lateinit var progessDialog:ProgressDialog

    private lateinit var firebaseAuth: FirebaseAuth
    private var email = "" //não entendi o porque, mas se eu colocasse email:String, não funcionava
    private var senha = ""

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityLoginBinding.inflate(layoutInflater)
        setContentView(binding.root)

        //Barra de ação
        actionBar = supportActionBar!!
        actionBar.title = "Login"

        //Barra de progresso
        progessDialog =  ProgressDialog(this)
        progessDialog.setTitle("Por favor, espere um momento")
        progessDialog.setMessage("Entrando na sua conta...")
        progessDialog.setCanceledOnTouchOutside(false)


        //Init firebaseAuth
        firebaseAuth = FirebaseAuth.getInstance()
        checkUser()

        //Ao clicar na menssagem "Crie", inicia o cadastro de uma nova conta
        binding.noAcount.setOnClickListener {
            startActivity(Intent(this, SignUpActivity::class.java))
        }

        //Inicia o login
        binding.btnLogin.setOnClickListener {
            validationData()
        }
    }

    private fun validationData() {
        //basicamente um FindViewById
        email = binding.inputTextEmailL.text.toString().trim()
        senha = binding.inputTextSenhaL.text.toString().trim()

        if (!Patterns.EMAIL_ADDRESS.matcher(email).matches())
        {
            //formato de email invalido
            binding.inputTextEmailL.error = "Email invalido, insira um email verdadeiro(?)"
        }
        else if(TextUtils.isEmpty(senha))
        {
            //senha não inserida
            binding.inputTextSenhaL.error = "Por favor, digite a sua senha"
        }
        else
        {
            firebaseLogin()
        }
    }

    private fun firebaseLogin() {
        progessDialog.show()
        firebaseAuth.signInWithEmailAndPassword(email, senha)
            // Se tudo der certo no Login
            .addOnSuccessListener {
                progessDialog.dismiss()
                val firebaseUser = firebaseAuth.currentUser
                val email = firebaseUser!!.email
                Toast.makeText(this, "Login realizado com sucesso",
                    Toast.LENGTH_SHORT).show()

                //Abre o perfil do usuario
                startActivity(Intent(this, UserProfileActivity::class.java))
                finish()
            }
            //Se der algo errado no login
            .addOnFailureListener { e->
                Toast.makeText(this, "Login falhou devido a ${e.message}",
                    Toast.LENGTH_SHORT).show()
                progessDialog.dismiss()
            }
    }

    //Checa se o usuario já está logado
    private fun checkUser() {
        val firebaseUser = firebaseAuth.currentUser
        if(firebaseUser != null)
        {
            startActivity(Intent(this, UserProfileActivity::class.java))
            finish()
        }

    }
}