package com.example.apppsicologia.Repository

import com.example.apppsicologia.Model.Teste

class TestRepository {
    private var repository: com.example.apppsicologia.Repository.TestRepository? = null

    fun getInstance(): com.example.apppsicologia.Repository.TestRepository? {
        if (repository == null) {
            repository = com.example.apppsicologia.Repository.TestRepository()
        }
        return repository
    }

    private val testList: ArrayList<Teste> = ArrayList<Teste>()

    fun save(test: Teste) {
        testList.add(test)
    }

    fun delete(test: Teste) {
        testList.remove(test)
    }

    fun getAll(): ArrayList<Teste>? {
        return testList
    }

    fun getByIndex(index: Int): Teste? {
        return testList[index]
    }

    fun update(index: Int, gift: Teste) {
        testList[index] = gift
    }
}