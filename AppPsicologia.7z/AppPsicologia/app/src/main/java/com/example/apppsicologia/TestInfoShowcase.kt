package com.example.apppsicologia

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView

class TestInfoShowcase : AppCompatActivity()  {
        override fun onCreate(savedInstanceState: Bundle?) {
            super.onCreate(savedInstanceState)
            setContentView(R.layout.info_showcase)
            val recyclerTestes = findViewById<RecyclerView>(R.id.recycler_testes)
            recyclerTestes.layoutManager = LinearLayoutManager(
                this,
                RecyclerView.VERTICAL,
                false
            )
    }
}