package com.example.apppsicologia.Repository

import com.example.apppsicologia.Model.Usuario

class UserRepository {
    private var repository: com.example.apppsicologia.Repository.UserRepository? = null

    fun getInstance(): com.example.apppsicologia.Repository.UserRepository? {
        if (repository == null) {
            repository = com.example.apppsicologia.Repository.UserRepository()
        }
        return repository
    }

    private val userList: ArrayList<Usuario> = ArrayList<Usuario>()

    fun save(user: Usuario) {
        userList.add(user)
    }

    fun delete(user: Usuario) {
        userList.remove(user)
    }

    fun getAll(): ArrayList<Usuario>? {
        return userList
    }

    fun getByIndex(index: Int): Usuario? {
        return userList[index]
    }

    fun update(index: Int, gift: Usuario) {
        userList[index] = gift
    }
}