package com.example.apppsicologia.Model

class Teste (
        val quantidade : Number,
        val nome : String,
        val sigla : String,
        val construto : String,
        val contexto : String,
        val idade : Number,
        val aplicacao : String,
        val tempoAplicacao : String,
        val correcao : String,
        val validade : String,
        val objetivo : String,
        val publicoAlvo : String,
        val descricao : String,
        val itens : String,
        val profissional : String
        )