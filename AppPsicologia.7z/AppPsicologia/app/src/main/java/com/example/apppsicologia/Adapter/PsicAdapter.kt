package com.example.apppsicologia.Adapter

import android.content.Intent
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.example.apppsicologia.Model.Teste
import com.example.apppsicologia.R
import com.example.apppsicologia.TestInfoShowcase

class PsicAdapter(private val testList:List<Teste>):
    RecyclerView.Adapter<PsicAdapter.TesteViewHolder>() {

    inner class TesteViewHolder(item: View) :
        RecyclerView.ViewHolder(item){

        init {
            item.setOnClickListener(View.OnClickListener { view ->
                val intent = Intent(view.context, TestInfoShowcase::class.java)
                view.context.startActivity(intent)
            })
        }
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): TesteViewHolder {

        val inflater = LayoutInflater.from(parent.context)

        val layout = inflater
            .inflate(
                R.layout.view_item_teste,
                parent,
                false
            )

        return TesteViewHolder(layout)
    }

    override fun onBindViewHolder(
        holder: com.example.apppsicologia.Adapter.PsicAdapter.TesteViewHolder,
        position: Int
    ) {
        val test: Teste = testList[position]
        val textViewPlayer: TextView = holder.itemView.findViewById<TextView>(R.id.text_test_teste)
        textViewPlayer.text = test.nome
    }

    override fun getItemCount(): Int {
        return testList.size
    }

}

