package com.example.apppsicologia.Model

class Med (val id: Number?,
           val email: String,
           val senha: String)