package com.example.apppsicologia;

import android.app.ProgressDialog
import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.text.TextUtils
import android.util.Patterns
import android.widget.Toast
import androidx.appcompat.app.ActionBar
import com.example.apppsicologia.databinding.ActivitySignUpBinding
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.ktx.firestore
import com.google.firebase.ktx.Firebase


class SignUpActivity : AppCompatActivity() {
    private lateinit var binding: ActivitySignUpBinding

    private lateinit var actionBar: ActionBar

    private lateinit var progessDialog:ProgressDialog

    private lateinit var firebaseAuth: FirebaseAuth
    private var email = ""
    private var senha = ""
    private var senhaConf = ""
    private var valid : Boolean = true

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivitySignUpBinding.inflate(layoutInflater)
        setContentView(binding.root)

        //Barra de ações
        actionBar = supportActionBar!!
        actionBar.title = "Cadastrar"
        //Botão para voltar pagina(activity)
        actionBar.setDisplayHomeAsUpEnabled(true)
        actionBar.setDisplayShowHomeEnabled(true)

        //Para de progresso, praticamente igual a de LoginActivity
        progessDialog =  ProgressDialog(this)
        progessDialog.setTitle("Por favor, espere um momento")
        progessDialog.setMessage("Sua conta está sendo criada...")
        progessDialog.setCanceledOnTouchOutside(false)


        //Init firebaseAuth
        firebaseAuth = FirebaseAuth.getInstance()
        var db = Firebase.firestore

        binding.btnCadastrar.setOnClickListener {
            validationData()
            if (valid){
                firebaseAuth.createUserWithEmailAndPassword(email, senha).addOnSuccessListener {  }
            }
        }



    }

    private fun validationData() {
        email = binding.inputTextEmailL.text.toString().trim()
        senha = binding.inputTextSenhaL.text.toString().trim()
        senhaConf = binding.inputTextSenhaConf.text.toString().trim()

        if(!Patterns.EMAIL_ADDRESS.matcher(email).matches())
        {
            binding.inputTextEmailL.error = "Formato de email invalido"
        }
        else if(TextUtils.isEmpty(senha))
        {
            binding.inputTextSenhaL.error = "Por favor, ensira uma senha"
        }
        else if (senha.length <6)
        {
            binding.inputTextSenhaL.error = "A senha precisa ter no mínimo 6 digitos"
        }
        else if (senha != senhaConf)
        {
            binding.inputTextSenhaConf.error = "As duas senhas não são compativeis"
        }
        else
        {
            firebaseSignUp()
        }
    }

    private fun firebaseSignUp() {
        progessDialog.show()

        firebaseAuth.createUserWithEmailAndPassword(email, senha)
            .addOnSuccessListener {
                progessDialog.dismiss()
                val firebaseUser = firebaseAuth.currentUser
                val email = firebaseUser!!.email
                Toast.makeText(this, "O cadastro foi concluido com sucesso!",
                    Toast.LENGTH_SHORT).show()

                startActivity(Intent(this, UserProfileActivity::class.java))
                finish()
            }
            .addOnFailureListener { e->
                progessDialog.dismiss()
                Toast.makeText(this, "O cadastro falhou devido a ${e.message}",
                    Toast.LENGTH_SHORT).show()
                progessDialog.dismiss()
            }
    }

    //Quando o botão de voltar for precionado, retorna para activity anterior
    override fun onSupportNavigateUp(): Boolean {
        onBackPressed()
        return super.onSupportNavigateUp()
    }
}